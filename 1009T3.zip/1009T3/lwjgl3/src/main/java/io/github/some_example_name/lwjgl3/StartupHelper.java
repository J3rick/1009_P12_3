package io.github.some_example_name.lwjgl3;

public class StartupHelper {
    public static void startNewJvmIfRequired() {
        System.out.println("Starting new JVM instance if required...");
    }
}
